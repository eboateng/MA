/*
 * Copyright (C) 2012-2020 Motion Systems
 * 
 * This file is part of ForceSeat motion system.
 *
 * www.motionsystems.eu
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT
 * LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */ 
#pragma once

#include <stdint.h>

#pragma pack(push, 1)
struct MSU_GyroPlayerData
{
	float accSway;
	float accSurge;
	float accHeave;
	float sway;
	float surge;
	float heave;
	float rollRate;
	float pitchRate;
	float yawRate;
	float roll;
	float pitch;
	float yaw;
};
#pragma pack(pop)

enum MSU_GyroPlayerErrorCode
{
	MSU_GPEC_Ok = 0,
	MSU_GPEC_EmptyFile,
	MSU_GPEC_ColumnIndexOutOfRange,
	MSU_GPEC_InvalidColumnMapping,
	MSU_GPEC_AlreadyPlaying,
	MSU_GPEC_InvalidPointer,
};

enum MSU_GyroPlayerRole
{
	MSU_GPR_AccSway = 0, // m/s2
	MSU_GPR_AccSurge,
	MSU_GPR_AccHeave,

	MSU_GPR_Sway,      // m
	MSU_GPR_Surge,
	MSU_GPR_Heave,

	MSU_GPR_RollRate,  // rad/s
	MSU_GPR_PitchRate,
	MSU_GPR_YawRate,

	MSU_GPR_Roll, // rad
	MSU_GPR_Pitch,
	MSU_GPR_Yaw
};

enum MSU_GyroPlayerTimeUnit
{
	MSU_GPR_Milliseconds = 0,
	MSU_GPR_Seconds
};

enum MSU_GyroPlayerMappingInversion
{
	MSU_GPR_NotInverted = 0,
	MSU_GPR_Inverted
};

typedef void (*MSY_GyroPlayerCallback)(const MSU_GyroPlayerData* data, void* userData);
