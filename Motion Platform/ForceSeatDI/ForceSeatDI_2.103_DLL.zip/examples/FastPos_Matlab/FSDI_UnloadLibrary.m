function FSDI_UnloadLibrary()
    unloadlibrary ForceSeatDI64
end
