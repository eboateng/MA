function blkStruct = slblocks

		Browser.Library = 'ForceSeatDI_Simulink';
		Browser.Name = 'MotionsSystems ForceSeatDI';

		blkStruct.Browser = Browser;