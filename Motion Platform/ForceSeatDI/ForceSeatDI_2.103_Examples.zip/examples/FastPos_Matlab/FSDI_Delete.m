function FSDI_Delete(api)
    calllib(FSDI_Dll(),'ForceSeatDI_Delete', api);
end
